global X Xsin Xomega D Dsin Domega kp ki kii;

% parametry sygna��w zadanych (blok: generator sygna�u zadanego)
X = 0.1;
Xsin = 0.1;
Xomega = 0.5;

% parametry sygna�u zak��caj�cego (blok: generator zak��cenia)
D = 0.5;
Dsin = 0.2;
Domega = 1;

% parametry regulator�w (blok: regulator)
kp = 2; 
ki = 3;
kii = 0.1;