 % po wywo�aniu symulacji w modelu LabURA_cw6 nalezy uruchomi� skrypt
clear  common_el x_new x_rms
% unormowanie d�ugo�ci wektor�w opisuj�cych sygna�y z symulacji 
x_extended = repmat(x.Time,[1 length(x_hat.Time)]);
[minValue,closestIndex] = min(abs(bsxfun(@minus,x_extended,x_hat.Time')));
x_new = zeros(size(x.Data));
x_new(closestIndex,1) = x_hat.Data;
for k = 2:size(x_new,1)
    if x_new(k) == 0
        x_new(k) = x_new(k - 1);
    end
end


% warto�� b��du �redniokwadratowego
x_rms = sqrt(sum((x.Data - x_new).^2)/length(x.Data))

% plot(x.Time,x.Data)
% hold on
% plot(x.Time,x_new)
% plot(x_hat.Time,x_hat.Data)
 
 