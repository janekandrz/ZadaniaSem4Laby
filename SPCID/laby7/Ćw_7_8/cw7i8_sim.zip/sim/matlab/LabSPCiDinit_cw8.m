%% zadanie 6.1
kp = 1;
Ti = 0.1;
Tp = 0.01;

%% zadanie 6.5

% global uI_1 uD_1 e_1 Tp kp ki kd T
% uI_1=0; uD_1=0; e_1=0;
% Tp=0.01;
% 
% %kp = ; wpisa� warto�� z Tune bloku PID
% %ki = ; wpisa� warto�� z Tune bloku PID
% %kd = ; wpisa� warto�� z Tune bloku PID
% %T = ; wpisa� warto�� z Tune bloku PID, przy czym T=1/N