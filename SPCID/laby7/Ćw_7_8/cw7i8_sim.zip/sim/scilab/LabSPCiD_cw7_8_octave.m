%zad 3
s=tf('s');
G=1/(3*s^2+s +1)
disp('Tp=2');
Tp=2;
Gzoh=c2d(G,Tp,'zoh') 
Gimp=c2d(G,Tp,'impulse')
Gt=c2d(G,Tp,'tustin')
z=tf('z',Tp);
Geb=z^2*Tp^2/(z^2*(3+Tp+Tp^2)+z*(-6-Tp)+3)
%Gtust=(Tp^2*z^2+50*z+Tp^2)/(z^2*(12+2*Tp+Tp^2)+z*(-24+2*Tp^2)+12-2*Tp+Tp^2)
%ltiview(G,Gzoh,Gfoh,Gimp,Gt,Geb)
step(G,Gzoh,Gimp,Gt,Geb)
figure,pzmap(Gzoh),figure,pzmap(Gimp),figure,pzmap(Gt),figure,pzmap(Geb)

disp('Tp=0,1');
Tp=.1;
Gzoh=c2d(G,Tp,'zoh')
Gimp=c2d(G,Tp,'imp')
Gt=c2d(G,Tp,'tustin')
z=tf('z',Tp);
Geb=z^2*Tp^2/(z^2*(3+Tp+Tp^2)+z*(-6-Tp)+3)
%ltiview(G,Gzoh,Gfoh,Gimp,Gt,Geb)
figure;step(G,Gzoh,Gimp,Gt,Geb)
figure,pzmap(Gzoh),figure,pzmap(Gimp),figure,pzmap(Gt),figure,pzmap(Geb)

%zad 4  pole zero plot
Gob=1/(s+1)^3; Tp=4;
Gob_zoh=c2d(Gob,Tp,'zoh');
Gzd=feedback(2*Gob_zoh,1)
figure,pzmap(Gzd)
Gzc=feedback(2*Gob,1)
figure,pzmap(Gzc)